package com.example.cardealership;

public interface HeaderCommunicator {
    public void respondTitle();
}
