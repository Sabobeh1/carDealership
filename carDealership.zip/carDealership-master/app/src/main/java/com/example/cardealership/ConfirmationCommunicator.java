package com.example.cardealership;

public interface ConfirmationCommunicator {
    public void respondYes();
    public void respondCancel();

}
