package com.example.cardealership;

import static java.lang.Thread.sleep;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.regex.Pattern;

public class ProfileActivity extends AppCompatActivity implements HeaderCommunicator{

    Button buttonSubmit;
    DataBaseHelper dataBaseHelper = new DataBaseHelper(ProfileActivity.this, User.dbName, null,1);


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        buttonSubmit = (Button) findViewById(R.id.buttonSubmitSignUp2);

    }

    @Override
    protected void onStart(){
        super.onStart();

        InputFieldsFragment fieldsFragment = (InputFieldsFragment) getSupportFragmentManager().findFragmentById(R.id.fragmentInputFields);

        SharedPrefManager sharedPrefManager = SharedPrefManager.getInstance(this);
        String currentUser = sharedPrefManager.readString("loggedInEmail", "");

        fieldsFragment.setEmailActivated(false);
        fieldsFragment.setEmailClickable(false);
        fieldsFragment.setEmailFocusable(false);
        fieldsFragment.setEmail(currentUser);



        Cursor user_cur = dataBaseHelper.getUsersByEmail(currentUser);

        while(user_cur.moveToNext()){
            fieldsFragment.setFname(user_cur.getString(1).toString());
            fieldsFragment.setLname(user_cur.getString(2).toString());
            fieldsFragment.setGender(user_cur.getString(3).toString().equals("Male") ? 0 : 1);
            fieldsFragment.setPhone(user_cur.getString(7).toString());
        }

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!(patternMatches(fieldsFragment.getFname(), "[a-zA-Z]{3,20}"))){
                    Toast.makeText(ProfileActivity.this, "BAD FIRST NAME", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(!(patternMatches(fieldsFragment.getLname(), "[a-zA-Z]{3,20}"))){
                    Toast.makeText(ProfileActivity.this, "BAD LAST NAME", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(!fieldsFragment.getPassword().isEmpty()) {
                    if (!(patternMatches(fieldsFragment.getPassword(), "^(?=.*[0-9])" + "(?=.*[a-z])(?=.*[A-Z])" + "(?=.*[@#$%^&+=])" + "(?=\\S+$).{8,20}$"))) {
                        Toast.makeText(ProfileActivity.this, "Make sure Password is between 8-20 characters, contains at least one number and one special character", Toast.LENGTH_LONG).show();
                        return;
                    }
                }
                if (!fieldsFragment.getPassword().equals(fieldsFragment.getConfirmPassword())) {
                    Toast.makeText(ProfileActivity.this, "Confirm Password and Password fields don't match", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (!(patternMatches(fieldsFragment.getPhone(), "^\\d{9}$"))){
                    Toast.makeText(ProfileActivity.this, "Make sure your phone number is correct(9 digits after the code)", Toast.LENGTH_SHORT).show();
                    return;
                }

                Cursor user = dataBaseHelper.getUsersByEmail(currentUser);
                user.moveToNext();

                sharedPrefManager.writeString("loggedInFirstName", fieldsFragment.getFname());

                Cursor update = dataBaseHelper.updatetUser(fieldsFragment.getEmail(), fieldsFragment.getFname(),
                        fieldsFragment.getLname(), fieldsFragment.getGender(),
                        fieldsFragment.getPassword().isEmpty() ?
                                user.getString(4).toString() :
                                fieldsFragment.getPassword(), fieldsFragment.getCity(),
                        fieldsFragment.getPhone());

                update.moveToNext();

                Toast.makeText(ProfileActivity.this, "SUCCESSFULLY UPDATED USER", Toast.LENGTH_SHORT).show();
                ProfileActivity.this.startActivity(new Intent(ProfileActivity.this, NavigationActivity.class));
                finish();
            }
        });

    }

    @Override
    public void respondTitle(){
        HeaderLabelFragment titleFragment = (HeaderLabelFragment) getSupportFragmentManager().findFragmentById(R.id.fragmentHeader);
        titleFragment.setTitle("PROFILE");
    }

    public static boolean patternMatches(String str, String regexPattern) {
        return Pattern.compile(regexPattern, Pattern.CASE_INSENSITIVE)
                .matcher(str)
                .matches();
    }
}