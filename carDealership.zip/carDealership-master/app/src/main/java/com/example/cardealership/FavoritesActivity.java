package com.example.cardealership;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FavoritesActivity extends AppCompatActivity implements HeaderCommunicator, PopUpCommunicator, AdapterView.OnItemSelectedListener{
    ImageView backgroundImg;

    Spinner spinnerFilter;
    ArrayAdapter<String> filterAd;

    EditText editTextSearchField;
    ListView listFavouriteCars;
    PopUpFragment popUpFragment;
    SubmitPopUpFragment submitPopUpFragment;

    static ArrayList<Car> tempCarList;

    CarListCustomAdapter carListCustomAdapter;

    FragmentManager fragmentManager;

    static Car currentCar = new Car();

    DataBaseHelper dataBaseHelper = new DataBaseHelper(FavoritesActivity.this, User.dbName, null,1);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorites);
        backgroundImg = (ImageView) findViewById(R.id.imageBackground);
        backgroundImg.startAnimation(AnimationUtils.loadAnimation(this, R.anim.scale));

        SharedPrefManager sharedPrefManager =SharedPrefManager.getInstance(this);

        tempCarList = new ArrayList<>();
        for(Car car : Car.carList){
            Cursor c = dataBaseHelper.getFavoritesByCarID(this, car.getId());
            boolean isThisCarInFavourite = false;

            while(c.moveToNext()){
                if(c.getString(0).equals(sharedPrefManager.readString("loggedInEmail", ""))){
                    isThisCarInFavourite = true;
                    break;
                }
            }
            if(isThisCarInFavourite){
                tempCarList.add(car);
            }
        }
        fragmentManager = getSupportFragmentManager();
        popUpFragment = new PopUpFragment();
        submitPopUpFragment = new SubmitPopUpFragment();

        spinnerFilter = (Spinner) findViewById(R.id.spinnerFilter);
        editTextSearchField = (EditText) findViewById(R.id.editTextSearchField);

        listFavouriteCars = (ListView) findViewById(R.id.listFavouriteCars);

        carListCustomAdapter = new CarListCustomAdapter(tempCarList, this);

        listFavouriteCars.setAdapter(carListCustomAdapter);

        listFavouriteCars.setOnItemSelectedListener(this);



        filterAd = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, new String[]{"PRICE", "NAME", "ID"});
        filterAd.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerFilter.setAdapter(filterAd);
        spinnerFilter.setOnItemSelectedListener(this);

        popUpFragment = new PopUpFragment();

        editTextSearchField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String StringSearchField =  editTextSearchField.getText().toString();
                String StringFilter = spinnerFilter.getSelectedItem().toString();

                if (StringSearchField.equals("")) {
                    tempCarList.clear();
                    for(Car car : Car.carList){
                        Cursor c = dataBaseHelper.getFavoritesByCarID(FavoritesActivity.this, car.getId());
                        boolean isThisCarInFavourite = false;

                        while(c.moveToNext()){
                            if(c.getString(0).equals(sharedPrefManager.readString("loggedInEmail", ""))){
                                isThisCarInFavourite = true;
                                break;
                            }
                        }
                        if(isThisCarInFavourite){
                            tempCarList.add(car);
                        }
                    }
                    carListCustomAdapter.notifyDataSetChanged();
                    return;
                }

                tempCarList.clear();
                if (StringFilter.equals("PRICE")){
                    try {
                        int priceCenter = Integer.parseInt(StringSearchField);

                        for (Car car : Car.carList) {
                            if ((car.getPrice() < (.9 * priceCenter)) || (car.getPrice() > (1.1 * priceCenter)))
                                continue;

                            Cursor c = dataBaseHelper.getFavoritesByCarID(FavoritesActivity.this, car.getId());
                            boolean isThisCarInFavourite = false;

                            while(c.moveToNext()){
                                if(c.getString(0).equals(sharedPrefManager.readString("loggedInEmail", ""))){
                                    isThisCarInFavourite = true;
                                    break;
                                }
                            }
                            if(isThisCarInFavourite){
                                tempCarList.add(car);
                            }
                        }
                        carListCustomAdapter.notifyDataSetChanged();
                        Log.d("Nan exception", tempCarList.toString());
                    } catch (Exception e) {
                        Log.d("Nan exception", e.toString());
                    }

                }else if (StringFilter.equals("NAME")){
                    Pattern pattern = Pattern.compile( StringSearchField, Pattern.CASE_INSENSITIVE);

                    for (Car car : Car.carList) {
                        Matcher matcher = pattern.matcher(car.getType());
                        if (!matcher.find())
                            continue;

                        Cursor c = dataBaseHelper.getFavoritesByCarID(FavoritesActivity.this, car.getId());
                        boolean isThisCarInFavourite = false;

                        while(c.moveToNext()){
                            if(c.getString(0).equals(sharedPrefManager.readString("loggedInEmail", ""))){
                                isThisCarInFavourite = true;
                                break;
                            }
                        }
                        if(isThisCarInFavourite){
                            tempCarList.add(car);
                        }
                    }

                }else if (StringFilter.equals("ID")){
                    try {
                        int id = Integer.parseInt(StringSearchField);

                        for (Car car : Car.carList) {
                            if (car.getId() != id) {
                                continue;
                            }
                            Cursor c = dataBaseHelper.getFavoritesByCarID(FavoritesActivity.this, car.getId());
                            boolean isThisCarInFavourite = false;

                            while(c.moveToNext()){
                                if(c.getString(0).equals(sharedPrefManager.readString("loggedInEmail", ""))){
                                    isThisCarInFavourite = true;
                                    break;
                                }
                            }
                            if(isThisCarInFavourite){
                                tempCarList.add(car);
                            }
                            break;
                        }
                        carListCustomAdapter.notifyDataSetChanged();
                        Log.d("Nan exception", tempCarList.toString());
                    } catch (Exception e) {
                        Log.d("Nan exception", e.toString());
                    }
                }
                carListCustomAdapter.notifyDataSetChanged();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });




    }

    @Override
    public void respondTitle(){
        HeaderLabelFragment titleFragment = (HeaderLabelFragment) getSupportFragmentManager().findFragmentById(R.id.fragmentHeader);
        titleFragment.setTitle("Favourites");
    }



    @Override
    public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long id) {
        if (arg0.getId() == R.id.listFavouriteCars){
            Log.d("adapterParent", String.valueOf(R.id.listFavouriteCars));
        }else if (arg0.getId() == R.id.spinnerFilter){
            Log.d("adapterParent", String.valueOf(R.id.spinnerFilter));
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub
    }

    @Override
    public void respondPopUpLaunch(int ID, String type, int price){
        if (fragmentManager.getFragments().contains(popUpFragment))
            return;
        CarMenuActivity.currentCar.setType(type);
        CarMenuActivity.currentCar.setId(ID);
        CarMenuActivity.currentCar.setPrice(price);
        CarMenuActivity.currentCar.setIsSpecialOffer(false);

        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.LayoutPopUp, popUpFragment, "popUpFragment");
        fragmentTransaction.commit();

        listFavouriteCars.setEnabled(false);

    }

    @Override
    public void respondPopUpExit(){
        if (!fragmentManager.getFragments().contains(popUpFragment))
            return;
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.remove(popUpFragment);
        fragmentTransaction.commit();

        listFavouriteCars.setEnabled(true);
    }

    @Override
    public void respondOpenFragment(){
    }

    @Override
    public void addToFavourites(String email, int carID){
        dataBaseHelper.addToFavorites( this,email, carID);
    }

    @Override
    public void respondSubmitPopUpLaucnh(int ID, String type, int price){
        if (fragmentManager.getFragments().contains(submitPopUpFragment))
            return;
        CarMenuActivity.currentCar.setType(type);
        CarMenuActivity.currentCar.setId(ID);
        CarMenuActivity.currentCar.setPrice(price);
        CarMenuActivity.currentCar.setIsSpecialOffer(false);

        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.LayoutPopUp, submitPopUpFragment, "submitPopUpFragment");
        fragmentTransaction.commit();

        listFavouriteCars.setEnabled(false);
    }

    @Override
    public void respondSubmitPopUpExit(){
        if (!fragmentManager.getFragments().contains(submitPopUpFragment))
            return;
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.remove(submitPopUpFragment);
        fragmentTransaction.commit();

        listFavouriteCars.setEnabled(true);
    }
}