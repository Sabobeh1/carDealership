package com.example.cardealership;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Date;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public class LoginActivity extends AppCompatActivity {
    AutoCompleteTextView editTextEmail;
    EditText editTextPwd;

    Button buttonLogin;
    Button buttonSignUp;

    CheckBox checkBox;

    DataBaseHelper dataBaseHelper = new DataBaseHelper(LoginActivity.this, User.dbName, null,1);


    void initTables(DataBaseHelper dataBaseHelper){

        dataBaseHelper.clearCountryCityCarTables();
        dataBaseHelper.insertCountry("Palestinian Territory", "00970");
        dataBaseHelper.insertCity("Hebron", "Palestinian Territory");
        dataBaseHelper.insertCity("Ramallah", "Palestinian Territory");
        dataBaseHelper.insertCity("Nablus", "Palestinian Territory");

        dataBaseHelper.insertCountry("Jordan", "00962");
        dataBaseHelper.insertCity("Amman", "Jordan");
        dataBaseHelper.insertCity("Aqaba", "Jordan");
        dataBaseHelper.insertCity("Irbid", "Jordan");

        dataBaseHelper.insertCountry("Lebanon", "00961");
        dataBaseHelper.insertCity("Beirut", "Lebanon");
        dataBaseHelper.insertCity("Tripoli", "Lebanon");
        dataBaseHelper.insertCity("Sidon", "Lebanon");

        dataBaseHelper.insertCountry("Saudi Arabia", "00966");
        dataBaseHelper.insertCity("Mdinah", "Saudi Arabia");
        dataBaseHelper.insertCity("Riyadh", "Saudi Arabia");
        dataBaseHelper.insertCity("Jeddah", "Saudi Arabia");

//        //Insert 1 admin
        //admin user
        dataBaseHelper.insertAdminUser(LoginActivity.this, new User(
                        "admin@admin.com",
                        "ahmad",
                        "eiss",
                        "Male",
                        "admin@123",
                        "Palestinian Territory",
                        "Ramallah",
                        "598455262"
                ),
                true);

        for(Car car : Car.carList)
            dataBaseHelper.insertCar(car.getId(), car.getType(), car.getPrice());


        Cursor cursor = dataBaseHelper.getAllCars();
        while(cursor.moveToNext()){
            Log.d("carsDBTest", String.format("%d %s %d", cursor.getInt(0), cursor.getString(1), cursor.getInt(2)));
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        SharedPrefManager sharedPrefManager =SharedPrefManager.getInstance(this);
        Set<String> rememberedEmails = sharedPrefManager.readStringSet("RememberedEmails", new HashSet<>());
        String[] rememberedEmailsList = rememberedEmails.toArray(new String[rememberedEmails.size()]);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.select_dialog_singlechoice, rememberedEmailsList);

        editTextEmail = (AutoCompleteTextView) findViewById(R.id.editTextEmailLogin);
        editTextPwd = (EditText) findViewById(R.id.editTextPasswordLogin);

        editTextEmail.setThreshold(1);
        editTextEmail.setAdapter(adapter);

        buttonLogin = (Button) findViewById(R.id.button_Login);
        buttonSignUp = (Button) findViewById(R.id.button_SignUp);

        checkBox = (CheckBox) findViewById(R.id.checkBox_RemeberMe);

        initTables(dataBaseHelper);

        /*String currentUser = sharedPrefManager.readString("RememberedEmails", "");
        editTextEmail.setText(currentUser);*/

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor registeredUsers = dataBaseHelper.getUserEmailPassword(editTextEmail.getText().toString());
                while(registeredUsers.moveToNext()){
                    if (registeredUsers.getString(4).equals(editTextPwd.getText().toString())){
                        sharedPrefManager.writeString("loggedInEmail", editTextEmail.getText().toString());
                        if (checkBox.isChecked()){
                            Set<String> currRememberedEmails = sharedPrefManager.readStringSet("RememberedEmails", new HashSet<>());
                            if(!currRememberedEmails.contains(editTextEmail.getText().toString())){
                                currRememberedEmails.add(editTextEmail.getText().toString());
                            }
                            sharedPrefManager.writeStringSet("RememberedEmails", currRememberedEmails);
                        }

                        if (registeredUsers.getInt(6) == 1){
                            LoginActivity.this.startActivity(new Intent(LoginActivity.this, AdminNavigationMenuActivity.class));
                        } else {
                            LoginActivity.this.startActivity(new Intent(LoginActivity.this, NavigationActivity.class));
                        }
                        sharedPrefManager.writeString("loggedInFirstName", registeredUsers.getString(1).toString());
                        finish();
                    }else{
                        Toast.makeText(LoginActivity.this, "Wrong Password", Toast.LENGTH_SHORT).show();
                    }
                    return;
                }
                Toast.makeText(LoginActivity.this, "Email is not registered", Toast.LENGTH_SHORT).show();
            }
        });

        buttonSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent switchIntent = new Intent(LoginActivity.this, SignUpActivity.class);
                LoginActivity.this.startActivity(switchIntent);
                finish();
            }
        });


    }
}