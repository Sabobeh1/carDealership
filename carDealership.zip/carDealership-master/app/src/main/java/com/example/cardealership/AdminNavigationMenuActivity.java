package com.example.cardealership;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class AdminNavigationMenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_navigation_menu);
        SharedPrefManager sharedPrefManager = SharedPrefManager.getInstance(this);

        Button buttonLogout = (Button) findViewById(R.id.buttonLogout);

        TextView title = (TextView) findViewById(R.id.textViewNavigationHeader);
        title.setText("Hi Admin " + sharedPrefManager.readString("loggedInFirstName", "Habibi") + "!");

        buttonLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(AdminNavigationMenuActivity.this, LoginActivity.class));

                AdminNavigationMenuActivity.this.finish();
            }
        });
    }
}